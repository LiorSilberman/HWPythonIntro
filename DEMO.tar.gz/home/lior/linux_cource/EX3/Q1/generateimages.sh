#!/bin/bash

# vars
FULL_FILE_NAME="$1"
SCRIPT_PATH=$(dirname "$0")
FILE_NAME=$(basename "$1")
ERRORS=${SCRIPT_PATH}/errors.log

# check if file exist
if [ ! -f "${FULL_FILE_NAME}" ];then
    echo "File ${FILE_NAME} not exists"
    exit 1
fi

# check if file empty
if [ ! -s "${FULL_FILE_NAME}" ];then
    echo "File ${FILE_NAME} is empty"
    exit 1
fi

# Initialize a counter
py_file_count=0

# Iterate over files in the directory
for file in "$SCRIPT_PATH"/*.py; do
    if [ -f "$file" ]; then
        ((py_file_count++))
    fi
done

# Check the count of Python files
if [ "$py_file_count" -ne 1 ]; then
    echo "Either no .py files or more than one .py file found in the directory."
    exit 1
fi

FIND_COMMAND="/usr/bin/find"
PYTHON3="/usr/bin/python3"

# get py fileName
PYTHON_FILE=$($FIND_COMMAND ${SCRIPT_PATH} -type f -name "*.py")

# run python
while IFS= read -r line; do 
    # check size of parameters greater then 2
    IFS=' ' read -r -a params <<< "$line"
    if [ ${#params[@]} -lt 3 ]; then
        echo "The string does not contain at least three parameters." >> "$ERRORS"
        continue 2
    fi

    # check if all parameters from the 3rd parameter till the last parameter are numbers
    for ((i = 2; i < ${#params[@]}; i++)); do
        if ! [[ ${params[i]} =~ ^[0-9]+$ ]]; then
            echo "Parameter "${params[i]}" is not a number." >> "$ERRORS"
            continue 2  # Skip to the next line in the input file
        fi
    done

    # run file
    $PYTHON3 ${PYTHON_FILE} $line

done <${FULL_FILE_NAME}