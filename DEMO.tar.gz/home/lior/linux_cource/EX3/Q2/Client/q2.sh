#!/bin/bash

# check there is only one parameter
if [ $# -ne 1 ]; then
    echo "ERROR: There is not exactly one parameter." 
    exit 1
fi

# get url
url="$1"

# substracting the string to get suffix name
API_SUFFIX=$(echo "$url" | sed 's/.*\///')
DATE_FORMAT=$(date +"%H_%M_%S")
# touch json file with date 
FILE_NAME="${API_SUFFIX}_${DATE_FORMAT}.json"

# save response to json file
curl "$url" > $FILE_NAME