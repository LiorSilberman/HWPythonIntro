// Requiring express in our server
const express = require('express');
const app = express();

var bodyParser = require('body-parser');
var path = require('path');
var fs = require('fs');

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

// Defining get request at '/multiple' route
app.get('/', function(req, res) {
    res.json({
        user: 1,
        name: 'Lior',
        image: 'https://reqres.in/img/faces/1-image.jpg'
    });
});
// Defining get request at '/array' route
app.get('/array', function(req, res) {
    res.json([{
        user: 1,
        name: 'Lior',
        url: 'https://reqres.in/img/faces/1-image.jpg'
      },
      {
        user: 2,
        name: 'Bana',
        url: 'https://reqres.in/img/faces/2-image.jpg'
      }
    ]);
});

app.get('/images', function(req, res) {
    const jsonImagesText = fs.readFileSync('images.json')
    let imagesArr =  JSON.parse(jsonImagesText)
    return res.json(imagesArr);    
});

// Defining get request at '/' route
app.get('/images/:id', function(req, res) {
    const jsonImagesText = fs.readFileSync('images.json')
    var idRequest = req.params.id;
    let imagesArr =  JSON.parse(jsonImagesText);
    const imageObj = imagesArr.find(img => img.id === idRequest)
    if (imageObj)
    {
        res.json(imageObj);
    }    
    else
    {
        return res.status(404).send({ error: true, msg: 'image not found...' })
    }    
})

// Setting the server to listen at port 3000
app.listen(3000, function(req, res) {
    console.log("Server is running at port 3000");
});